
#include "main.h"
#include "stm32f4xx_it.h"

extern SPI_HandleTypeDef hspi2;
extern UART_HandleTypeDef huart2;

void SysTick_Handler(void)
{

  HAL_IncTick();

}



void UART2_IRQHandler(void)
{
	HAL_UART_IRQHandler(&huart2);
}
